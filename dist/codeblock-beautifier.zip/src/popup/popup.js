// From themes.js
new ThemeOptions(themes)
new ParseButton()
new ThemeSwitch()
